<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: LA.php");
  exit;
}
require 'K.php';
if (!isset($_GET['id'])) {
  header("Location: IAS.php");
  exit;
}
$id = $_GET['id'];


$s = query2("SELECT * FROM sekolah WHERE id = $id");


if (isset($_POST['ubah2'])) {
  if (ubah2($_POST) > 0) {
    echo "<script>
            alert('data berhasil diubah');
            document.location.href = 'IAS.php';
         </script>";
  } else {
    echo "data gagal diubah!";
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
button[type=submit]{
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  margin: 5px 0px 20px 40px;
  border: none;
  cursor: pointer;
  max-width: 500px;
  border-radius: 20px;
}
input[type=text],input[type=date]{
	width: 90%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
	font-size:20px;
}
body{
  background-image: url('img/92906953_p0_master1200.jpg');
  background-repeat: no-repeat;
  background-position: centered;
  background-attachment: fixed;
  background-size: 100% 100%;
}
.border{
	padding: 10px 35px 10px 0px;
	border: 1px solid black;
	background-color:white;
	border-radius: 12px;
	max-width:500px;
	margin: auto;
	font-size:20px;
}
.center{
	padding: 30px 0;
    border: none;
    text-align: center;
}
h1{
	font-size:50px;
}
.overlay {
  width: 100%;
  height: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
  overflow-x: hidden;
  transition: 0.5s;
}

.overlay-content {
  position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
  margin-top: 30px;
}

.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
  color: #f1f1f1;
}

.overlay .closebtn {
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}

@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .overlay .closebtn {
  font-size: 40px;
  top: 15px;
  right: 35px;
  }
}
</style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ubah Data Sekolah</title>
</head>

<body>
<div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
    <a href="DE.php">Tambah Data Siswa</a>
	<a href="S.php">Tambah Data Sekolah</a>
	<a href="IA.php">Data Siswa</a>
	<a href="IAS.php">Data Sekolah</a>
	<a href="L.php">Log Out</a>
  </div>
</div>
	<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<div class="center">
  <h1>Form Ubah Data Sekolah</h1> 
  <form action="" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $s['id']; ?>">
	<div class="border">
		<ul>
        <label>
          Nama :
          <input type="text" name="nama_sekolah" autofocus required value="<?= $s['nama_sekolah']; ?>">
        </label>
		</ul>
		<ul>
        <label>
          Alamat :
          <input type="text" name="alamat" required value="<?= $s['alamat']; ?>">
        </label>
		</ul>
		<ul>		
        <label>
          Telepon :
          <input type="text" name="telepon" required value="<?= $s['telepon']; ?>">
        </label>
		</ul>		
        <button type="submit" name="ubah2">Ubah Data</button>
		</div>
  </form>
  </div>
  <script>
  function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}
  </script>
</body>

</html>