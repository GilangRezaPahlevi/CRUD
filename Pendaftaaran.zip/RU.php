<?php
require 'K.php';

if (isset($_POST['registrasi'])) {
  if (registrasi($_POST) > 0) {
    echo "<script>
            alert('user baru berhasil ditambahkan. silahkan login!');
            document.location.href = 'LU.php';
          </script>";
  } else {
    echo 'user gagal ditambahkan!';
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
button[type=submit]{
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  margin: 5px 0px 20px 40px;
  border: none;
  cursor: pointer;
  max-width: 500px;
  border-radius: 20px;
}
input[type=text],input[type=password]{
	width: 90%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
	font-size:20px;
}
body{
  background-image: url('img/92906953_p0_master1200.jpg');
  background-repeat: no-repeat;
  background-position: centered;
  background-attachment: fixed;
  background-size: 100% 100%;
}
.border{
	padding: 10px 35px 10px 0px;
	border: 1px solid black;
	background-color:white;
	border-radius: 12px;
	max-width:500px;
	margin: auto;
	font-size:20px;
}
.center{
	padding: 30px 0;
    border: none;
    text-align: center;
}
h1{
	font-size:50px;
}

.overlay {
  width: 100%;
  height: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
  overflow-x: hidden;
  transition: 0.5s;
}

.overlay-content {
  position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
  margin-top: 30px;
}

.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
  color: #f1f1f1;
}

.overlay .closebtn {
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}

@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .overlay .closebtn {
  font-size: 40px;
  top: 15px;
  right: 35px;
  }
}

</style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrasi User</title>
</head>

<body>
<div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
     <a href="RU.php">TAMBAH USER</a>
	<a href="LU.php">LOG IN USER</a>
	<a href="LA.php">LOG IN ADMIN</a>
  </div>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<div class="center">
  <h1>Form Registrasi User</h1>
  <div class="border">
  <form action="" method="POST">
    <ul>
        <label>
          Username:
          <input type="text" name="user" autofocus autocomplete="off" required>
        </label>
		</ul>
		<ul>
        <label>
          Password :
          <input type="password" name="password1" required>
        </label>
      </ul>
      <ul>
        <label>
          Konfirmasi Password :
          <input type="password" name="password2" required>
        </label>
      </ul>
      <ul>
        <button type="submit" name="registrasi">Registrasi</button>
    </ul>
  </form>
  </div>
  </div>
  <script>
 function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}
</script>
</body>

</html>