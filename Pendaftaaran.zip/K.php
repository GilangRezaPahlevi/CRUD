<?php
function koneksi()
{
  return mysqli_connect('localhost', 'root', '', 'loool');
}

function query($query)
{
  $conn = koneksi();
  $result = mysqli_query($conn, $query);

  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}
function query2($query2)
{
  $conn2 = koneksi();
  $result = mysqli_query($conn2, $query2);

if (mysqli_num_rows($result) == 1) {
    return mysqli_fetch_assoc($result);
  }
  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}
function D($data)
{

  $conn = koneksi();
  $nis = htmlspecialchars($data['nis']);
  $nama = htmlspecialchars($data['nama']);
  $tgl_lahir = htmlspecialchars($data['tgl_lahir']);
  $id_sekolah  = htmlspecialchars($data['id_sekolah']);
  $query =  "INSERT INTO siswa VALUES
            (NULL, '$nis','$nama','$tgl_lahir','$id_sekolah');
            ";
  mysqli_query($conn, $query) or die(mysqli_error($conn));
  echo mysqli_error($conn);
  return mysqli_affected_rows($conn);
}

function S($data)
{
  $conn = koneksi();
  $nama_Sekolah = htmlspecialchars($data['nama_sekolah']);
  $telepon = htmlspecialchars($data['telepon']);
  $alamat = htmlspecialchars($data['alamat']);
  
  $query =  "INSERT INTO sekolah VALUES
            (NULL, '$nama_Sekolah','$telepon','$alamat');
            ";
  mysqli_query($conn, $query) or die(mysqli_error($conn));
  echo mysqli_error($conn);
  return mysqli_affected_rows($conn);
}

function hapus($id)
{
  $conn = koneksi();
  $s = query("SELECT * FROM siswa WHERE id = $id");
  mysqli_query($conn, "DELETE FROM siswa WHERE id = $id") or die(mysqli_error($conn));
  return mysqli_affected_rows($conn);
}
function hapus2($id)
{
  $conn = koneksi();
  $s = query("SELECT * FROM sekolah WHERE id = $id");
  mysqli_query($conn, "DELETE FROM sekolah WHERE id = $id") or die(mysqli_error($conn));
  return mysqli_affected_rows($conn);
}

function ubah($data)
{
  $conn = koneksi();
  $id = $data['id'];
  $nis = htmlspecialchars($data['nis']);
  $nama = htmlspecialchars($data['nama']);
  $tgl_lahir = htmlspecialchars($data['tgl_lahir']);
  
  $query = "UPDATE siswa SET
              nis = '$nis',
              nama = '$nama',
              tgl_lahir = '$tgl_lahir'
			  
            WHERE id = $id";
  echo $query;
  mysqli_query($conn, $query) or die(mysqli_error($conn));
  echo mysqli_error($conn);
  return mysqli_affected_rows($conn);
}
function ubah2($data)
{
  $conn = koneksi();
  $id = $data['id'];
  $nama_sekolah = htmlspecialchars($data['nama_sekolah']);
  $alamat = htmlspecialchars($data['alamat']);
  $telepon = htmlspecialchars($data['telepon']);
  $query = "UPDATE sekolah SET
              nama_sekolah = '$nama_sekolah',
              alamat = '$alamat',
              telepon = '$telepon'
            WHERE id = $id";
  echo $query;
  mysqli_query($conn, $query) or die(mysqli_error($conn));
  echo mysqli_error($conn);
  return mysqli_affected_rows($conn);
}

function cari($keyword)
{
  $conn = koneksi();
  $query = "SELECT * FROM siswa WHERE 
              nama LIKE '%$keyword%'";
  $result = mysqli_query($conn, $query);
  $rows =  [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}
function cari2($keyword)
{
  $conn = koneksi();
  $query = "SELECT * FROM sekolah WHERE 
              nama_sekolah LIKE '%$keyword%'";
  $result = mysqli_query($conn, $query);
  $rows =  [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}
function login($data)
{
  $conn2 = koneksi();
  $user = htmlspecialchars($data['user']);
  $password = htmlspecialchars($data['password']);
  if ($user = query2("SELECT * FROM user WHERE user = '$user'")) {
    if (password_verify($password, $user['password'])) {
      $_SESSION['login'] = true;
      header("Location: index.php");
      exit;
    }
  }
  return [
    'error' => true,
    'pesan' => 'Username / Password Salah!'
  ];
}


function registrasi($data)
{
  $conn2 = koneksi();
  $username = htmlspecialchars(strtolower($data['username']));
  $password1 = mysqli_real_escape_string($conn2, $data['password1']);
  $password2 = mysqli_real_escape_string($conn2, $data['password2']);
  if (empty($username) || empty($password1) || empty($password2)) {
    echo "<script>
          alert('username / password tidak boleh  kosong!');
          document.location.href = 'RU.php';
          </script>";
    return false;
  }

  if (query2("SELECT * FROM user WHERE user = '$username'")) {
    echo "<script>
    alert('username sudah terdaftar!');
    document.location.href = 'RU.php';
    </script>";
    return false;
  }

  if ($password1 !== $password2) {
    echo "<script>
    alert('konfirmasi password tidak sesuai!');
    document.location.href = 'RU.php';
    </script>";
    return false;
  }

  if (strlen($password1) < 5) {
    echo "<script>
    alert('password terlalu pendek!');
    document.location.href = 'RU.php';
    </script>";
    return false;
  }

  $password_baru = password_hash($password1, PASSWORD_DEFAULT);
  $query2 = "INSERT INTO user 
              VALUES
              (null, '$username', '$password_baru')
              ";
  mysqli_query($conn2, $query2) or die(mysqli_error($conn2));
  return mysqli_affected_rows($conn2);
}
function login2($data)
{
  $conn2 = koneksi();
  $username = htmlspecialchars($data['username']);
  $passwordd = htmlspecialchars($data['passwordd']);
  if ($username = query2("SELECT * FROM admin WHERE username = '$username'")) {
    if (password_verify($passwordd, $username['passwordd'])) {
      $_SESSION['login'] = true;
      header("Location: IA.php");
      exit;
    }
  }
  return [
    'error' => true,
    'pesan' => 'Username / Password Salah!'
  ];
}


function registrasi2($data)
{
  $conn2 = koneksi();
  $username = htmlspecialchars(strtolower($data['username']));
  $password1 = mysqli_real_escape_string($conn2, $data['password1']);
  $password2 = mysqli_real_escape_string($conn2, $data['password2']);
  if (empty($username) || empty($password1) || empty($password2)) {
    echo "<script>
          alert('username / password tidak boleh  kosong!');
          document.location.href = 'RA.php';
          </script>";
    return false;
  }

  if (query2("SELECT * FROM admin WHERE username = '$username'")) {
    echo "<script>
    alert('username sudah terdaftar!');
    document.location.href = 'RA.php';
    </script>";
    return false;
  }
  if ($password1 !== $password2) {
    echo "<script>
    alert('konfirmasi password tidak sesuai!');
    document.location.href = 'RA.php';
    </script>";
    return false;
  }
  if (strlen($password1) < 5) {
    echo "<script>
    alert('password terlalu pendek!');
    document.location.href = 'RA.php';
    </script>";
    return false;
  }
  $password_baru = password_hash($password1, PASSWORD_DEFAULT);
  $query2 = "INSERT INTO admin 
              VALUES
              (null, '$username', '$password_baru')
              ";
  mysqli_query($conn2, $query2) or die(mysqli_error($conn2));
  return mysqli_affected_rows($conn2);
}
