<?php


require 'K.php';

if (!isset($_GET['id'])) {
  header("Location: IAS.php");
  exit;
}

$id = $_GET['id'];

if (hapus2($id) > 0) {
  echo "<script>
          alert('data berhasil dihapus');
          document.location.href = 'IAS.php';
       </script>";
} else {
  echo "data gagal ditambahkan!";
}
