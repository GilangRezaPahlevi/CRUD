<?php
session_start();
session_destroy();
header("Location: LU.php");
exit;
