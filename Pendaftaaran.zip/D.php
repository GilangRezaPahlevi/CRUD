<?php
require 'K.php';
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: LU.php");
  exit;
}

$sekolah = query("SELECT * FROM sekolah");
if (isset($_POST['D'])) {
  if (D($_POST) > 0) {
    echo "<script>
            alert('Data Berhasil Ditambahkan');
            document.location.href = 'index.php';
          </script>";
  } else {
    echo "data gagal ditambahkan!";
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
button[type=submit]{
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  margin: 5px 0px 20px 40px;
  border: none;
  cursor: pointer;
  max-width: 500px;
  border-radius: 20px;
}
input[type=text],input[type=date]{
	width: 90%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
	font-size:20px;
}
body{
  background-image: url('img/92906953_p0_master1200.jpg');
  background-repeat: no-repeat;
  background-position: centered;
  background-attachment: fixed;
  background-size: 100% 100%;
}
.border{
	padding: 10px 35px 10px 0px;
	border: 1px solid black;
	background-color:white;
	border-radius: 12px;
	max-width:500px;
	margin: auto;
	font-size:20px;
}
.center{
	padding: 30px 0;
    border: none;
    text-align: center;
}
h1{
	font-size:50px;
}
.custom-select {
  position: relative;
  font-family: Arial;
  font-size:20px;
  text-align:center;
  padding:0px 0px 15px 170px;
}

.custom-select select {
  display: none; 
  text-align:center;
}

.select-selected {
  background-color: #00bfff;
  text-align:center;
}

.select-selected:after {
  content: "";
  top: 14px;
  right: 10px;
  width: 500px;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 1px;
}

.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 13px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
  user-select: none;
  text-align:center;
}

.select-items {
  position: absolute;
  background-color: #00bfff;
  top: 100px;
  left: 170px;
  right: 0;
  z-index: 99;
}

.select-hide {
  display: none;
}

.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}
.overlay {
  width: 100%;
  height: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
  overflow-x: hidden;
  transition: 0.5s;
}

.overlay-content {
  position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
  margin-top: 30px;
}

.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
  color: #f1f1f1;
}

.overlay .closebtn {
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}

@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .overlay .closebtn {
  font-size: 40px;
  top: 15px;
  right: 35px;
  }
}
</style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Data Siswa</title>
</head>
<body>
<div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
  <a href="index.php">Data Siswa</a>
	<a href="L.php">Log Out</a>
  </div>
</div>
	<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<div class="center">
  <h1>FORM PENDAFTARAN SISWA</h1>
  <div class="border">
  <form action="" method="POST" enctype="multipart/form-data" id="FF">
		<ul>
        <label>
          NIS :
          <input type="text" name="nis" autofocus required >
        </label>
		</ul>
		<ul>
        <label>
          Nama :
          <input type="text" name="nama" required>
        </label>
		</ul>
		<ul>		
        <label>
          Tgl Lahir :
          <input type="date" name="tgl_lahir" required>
        </label>
		</ul>
		<div class="custom-select" style="width:200px;">
		<ul>
		<label>
		Nama Sekolah:
		   <select name="id_sekolah">
		   <option value="0">Pilih Sekolah:</option>
		   <?php foreach ($sekolah as $s) : ?>		   
		   <option value="<?= $s['id']; ?>"><?= $s['nama_sekolah']; ?></option>
		   <?php endforeach; ?>
		   </select>		   
		</ul>
		</label>
		</div>
        <button type="submit" name="D">Tambah Data</button>
  </form>  
	</div>
</div>
<script>
var x, i, j, l, ll, selElmnt, a, b, c;
x = document.getElementsByClassName("custom-select");
l = x.length;
for (i = 0; i < l; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  ll = selElmnt.length;
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < ll; j++) {
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        var y, i, k, s, h, sl, yl;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        sl = s.length;
        h = this.parentNode.previousSibling;
        for (i = 0; i < sl; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            yl = y.length;
            for (k = 0; k < yl; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  var x, y, i, xl, yl, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  xl = x.length;
  yl = y.length;
  for (i = 0; i < yl; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < xl; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
document.addEventListener("click", closeAllSelect);

function tampilkan(){
  var nama_kota=document.getElementById("id").kategori.value;
  if (nama_kota=="makanan")
    {
        document.getElementById("tampil").innerHTML="Anda Memilih <b>Makanan</b>";
    }
  else if (nama_kota=="minuman")
    {
        document.getElementById("tampil").innerHTML="Anda Memilih <b>Minuman</b>";
    }
}
function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}
</script>
</body>
</html>
