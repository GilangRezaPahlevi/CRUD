<?php


require 'K.php';

if (!isset($_GET['id'])) {
  header("Location: IA.php");
  exit;
}

$id = $_GET['id'];

if (hapus($id) > 0) {
  echo "<script>
          alert('data berhasil dihapus');
          document.location.href = 'IA.php';
       </script>";
} else {
  echo "data gagal ditambahkan!";
}
