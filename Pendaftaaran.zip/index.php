<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: LU.php");
  exit;
}
require 'K.php';
$siswa = query("SELECT siswa.id,siswa.nis,siswa.nama,siswa.tgl_lahir,sekolah.nama_sekolah FROM siswa,sekolah where siswa.id_sekolah = sekolah.id");
if (isset($_POST['cari'])) {
  $siswa = cari($_POST['keyword']);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('img/images.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  background-size:2%;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
  background-color:white;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
.center {
	padding:auto;
    margin-left: auto;
    margin-right: auto;
}
h1{
	text-align:center;
}
body{
  background-image: url('img/92906953_p0_master1200.jpg');
  background-repeat: no-repeat;
  background-position: centered;
  background-attachment: fixed;
  background-size: 100% 100%;
}
.overlay {
  width: 100%;
  height: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
  overflow-x: hidden;
  transition: 0.5s;
}

.overlay-content {
  position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
  margin-top: 30px;
}

.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
  color: #f1f1f1;
}

.overlay .closebtn {
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}

@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .overlay .closebtn {
  font-size: 40px;
  top: 15px;
  right: 35px;
  }
}
</style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar Siswa</title>
</head>
<body>
<div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
    <a href="D.php">TAMBAH DATA SISWA</a>
	<a href="L.php">Log Out</a>
  </div>
</div>
	<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
  <h1>Daftar Siswa</h1>
  

  <br><br>
  <form action="" method="POST">
   <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">

  </form>
    <table border="1" cellpadding="10" cellspacing="0" class="center" id="myTable">
      <tr>
        <th>Id</th>
        <th>Nis</th>
        <th>Nama</th>
        <th>Tgl lahir</th>
		<th>Nama Sekolah</th>
      </tr>
      <?php foreach ($siswa as $s):?>
        <tr>
            <td><?= $s['id']; ?></td>
            <td><?= $s['nis']; ?></td>
		    <td><?= $s['nama']; ?></td>
		    <td><?= $s['tgl_lahir']; ?></td>
			<td><?= $s['nama_sekolah']; ?></td>
		</tr>
		<?php endforeach ?>
    </table>
  <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}
</script>
</body>

</html>