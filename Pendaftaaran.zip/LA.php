<?php
session_start();
require 'K.php';
if (isset($_SESSION['login'])) {
  header("Location: IA.php");
  exit;
}
if (isset($_POST['login2'])) {
  $login2 = login2($_POST);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
button[type=submit]{
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  margin: 5px 0px 20px 40px;
  border: none;
  cursor: pointer;
  max-width: 500px;
  border-radius: 20px;
}
input[type=text],input[type=password]{
	width: 90%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
	font-size:20px;
}
body{
  background-image: url('img/92906953_p0_master1200.jpg');
  background-repeat: no-repeat;
  background-position: centered;
  background-attachment: fixed;
  background-size: 100% 100%;
}
.border{
	padding: 10px 35px 10px 0px;
	border: 1px solid black;
	background-color:white;
	border-radius: 12px;
	max-width:500px;
	margin: auto;
	font-size:20px;
}
.center{
	padding: 30px 0;
    border: none;
    text-align: center;
}
h1{
	font-size:50px;
}

.overlay {
  width: 100%;
  height: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0, 0.9);
  overflow-x: hidden;
  transition: 0.5s;
}

.overlay-content {
  position: relative;
  top: 25%;
  width: 100%;
  text-align: center;
  margin-top: 30px;
}

.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.overlay a:hover, .overlay a:focus {
  color: #f1f1f1;
}

.overlay .closebtn {
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}

@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .overlay .closebtn {
  font-size: 40px;
  top: 15px;
  right: 35px;
  }
}

</style>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
</head>

<body>
  <div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">
    <a href="RU.php">TAMBAH USER</a>
	<a href="LU.php">LOG IN USER</a>
	<a href="LA.php">LOG IN ADMIN</a>
  </div>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; MENU</span>
<div class="center">
  <h1>Form Login Admin</h1>
  <?php if (isset($login2['error'])) : ?>
    <p style="color: red; font-style:italic;"><?= $login2['pesan']; ?></p>
  <?php endif; ?>
  <div class="border">
  <form action="" method="POST">
    <ul>
        <label>
          Admin name :
          <input type="text" name="username" autofocus autocomplete="off" required>
        </label>
		</ul>
      <ul>
        <label>
          Password :
          <input type="password" name="passwordd" required>
        </label>
      </ul>
	  <ul>
        <button type="submit" name="login2">Login!</button>
    </ul>
  </form>
  </div>
</div>
  <script>
 function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}
</script>
</body>

</html>